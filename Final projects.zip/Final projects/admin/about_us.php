<?php include ('header.php'); ?>

        <div class="page-title">
            <div class="title_left">
                <h3>
					<small>Home /</small> About Us
                </h3>
            </div>
        </div>
        <div class="clearfix"></div>
 
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
							<br />
							<br />
                    <div class="x_title">
                        <h2><i class="fa fa-info"></i> Developer Information</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        <!-- If needed 
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Settings 1</a></li>
                                    <li><a href="#">Settings 2</a></li>
                                </ul>
                            </li>
						-->
                            <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <!-- content starts here -->

                <div class="" role="tabpanel" data-example-id="togglable-tabs">
                    <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Sadia Islam</a>
                        </li>
                   
                    </ul>
                    <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
							<fieldset class="pull-left" style="margin-left:230px;">
								<legend>Personal Information</legend>
									<dt>
										Age
										<ul>
											<li>
											23 years old
											</li>
										</ul>
									</dt>
									<dt>
										Civil Staus
										<ul>
											<li>
											Single
											</li>
										</ul>
									</dt>
									<dt>
										Date of Birth
										<ul>
											<li>
											April 14, 1999
											</li>
										</ul>
									</dt>
									<dt>
										Place of Birth
										<ul>
											<li>
											kushtia
											</li>
										</ul>
									</dt>
									<dt>
										Citizenship
										<ul>
											<li>
											Bangladeshi
											</li>
										</ul>
									</dt>
									<dt>
										Sex
										<ul>
											<li>
											Female
											</li>
										</ul>
									</dt>
							</fieldset>
							<fieldset class="pull-right" style="margin-right:200px;">
								<legend>Education</legend>
									<dt>
										Course
										<ul>
											<li>
											Bachelor of Computer Science and Engineering 
											</li>
										</ul>
									</dt>
									<dt>
										School
										<ul>
											<li>
											Independent University ,Bangladesh
											</li>
										</ul>
									</dt>
									<dt>
										School Year
										<ul>
											<li>
											2019 – 2025
											</li>
										</ul>
									</dt>
							</fieldset>
                        </div>
                      
						
                        <!-- content ends here -->
                    </div>
                </div>
            </div>
        </div>

<?php include ('footer.php'); ?>
